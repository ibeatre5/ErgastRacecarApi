

$('#getData').on('click', e => {
    $.getJSON('http://ergast.com/api/f1/2008/2/driverstandings.json', res=>{
        var data = res.MRData.StandingsTable.StandingsLists[0].DriverStandings;
        var tbody= $('#racerData')
        for (let i = 0; i < data.length; i++) {
            tbody.append(
                `<tr>
                <td>${data[i].position}</td>
                <td><a href="${data[i].Driver.url}">${data[i].Driver.givenName} ${data[i].Driver.familyName}</a></td>
                <td>${data[i].Driver.dateOfBirth}</td>
                <td><a href="${data[i].Constructors[0].url}">${data[i].Constructors[0].name}</a></td>
                <td>${data[i].Driver.nationality}</td>
                <td>${data[i].wins}</td>
                <td>${data[i].points}</td>
                </tr>`
               
            )
        }
    })
})

                        
            
   


// $('#weatherForm').on('submit', function (e) {
//     e.preventDefault();
//     var searchTerm = $('#racer_input').val().toLowerCase()


// $.getJSON('http://ergast.com/api/f1/2008/1/driverstandings.json', ())

// $('#getData').on('click', e =>{
//     $.getJSON('http://ergast.com/api/f1/2008/2/driverstandings.json',
//         function (res) {
//             // $('#show-data').css('display', 'block');
//             var data = res.MRData.StandingsTable.StandingsLists[0].DriverStandings
//             for (let i = 0; i < data.length; i++) {
//                 $('show-data').html(
//                     `<tr>
//                         <td>${data[i].points}</td>
//                     </tr>`
                
                // var tr = document.createElement('TR');
                // var td = document.createElement('TD');
                // tr.appendChild(td)
                // var node = document.createTextNode(data[i].position)
                // tr.appendChild(node);

                // $('#position').text(data[i].position)
                // $('#url').html(`<a href="${data[i].Driver.url}">${data[i].Driver.givenName} ${data[i].Driver.familyName}</a>`)
                // $('#dob').text((data[i].Driver.dateOfBirth))

                // $('#constructor').html(`<a href=" ${data[i].Constructors[0].url}">${data[i].Constructors[0].constructorId}</a>`)

                // $('#points').text(data[i].points)
                // $('#wins').text(data[i].wins)
